package com.quest.dematic;

import io.quarkus.test.junit.QuarkusTest;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.*;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;



import static org.hamcrest.CoreMatchers.is;

import javax.ws.rs.core.Response;


@QuarkusTest
public class OrderResourceTest {

    @Test
    public void testHelloEndpoint() {
        given()
          .when().get("/hello")
          .then()
             .statusCode(200)
             .body(is("Hello from RESTEasy Reactive"));
  }
    @Test
    @Order(1)
    public void findAll() {
   
    	    given()
    	        .when()
    	        .get("/orders")
    	        .then()
    	        .body("size()", equalTo(2))
    	        .body("id", hasItems(1, 2))
    	        .body("status", hasItems("COMPLETED", "PENDING"))
    	        .body("createdDate", hasItem("2022-09-01"))
    	        .statusCode(Response.Status.OK.getStatusCode());
    	  }
    
    @Test
    public void getById() {
    	  given()
          .when()
          .get("/orders/id")
          .then()
          .body("id", equalTo(1))
          .body("status", equalTo("COMPLETED"))
          .body("createdDate", equalTo("2022-09-01"))
          .statusCode(Response.Status.OK.getStatusCode());
    }
    	
    
    @Test
    public void getBystatus() {
    	 given()
         .when()
         .get("/orders/status")
         .then()
         .body("id", equalTo(1))
         .body("status", equalTo("COMPLETED"))
         .body("createdDate", equalTo("2022-09-01"))
         .statusCode(Response.Status.OK.getStatusCode());
   }
    	
    
    @Test
    public void getStatus() {
    }
    
}