package com.quest.dematic.Responder;
import com.quest.dematic.entity.OrderDtos;

import com.quest.dematic.entity.Orders;
import com.quest.dematic.mapping.OrderDtosMapper;

import io.order.process.system.Common.Responder;
import io.smallrye.mutiny.Multi;

public class OrderMultiResponder implements Responder<Multi<Orders>, Multi<OrderDtos>> {

    private final OrderDtosMapper orderDtosMapper;

    public OrderMultiResponder(OrderDtosMapper orderDtosMapper) {
		// TODO Auto-generated constructor stub
	 
        this.orderDtosMapper = orderDtosMapper;
    }

    @Override
    public Multi<OrderDtos> respond(Multi<Orders> order) {
        return order.onItem().transform(orderDtosMapper::map);
    }
}


