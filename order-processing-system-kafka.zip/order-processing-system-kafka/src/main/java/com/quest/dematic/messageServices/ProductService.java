//package com.quest.dematic.messageServices;
//
//import javax.enterprise.context.ApplicationScoped;
//import javax.inject.Inject;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.quest.dematic.entity.Product;
//import com.quest.dematic.repository.ProductRepository;
//
//import io.quarkus.hibernate.orm.panache.Panache;
//import io.smallrye.mutiny.Multi;
//import io.smallrye.mutiny.Uni;
//
//@ApplicationScoped
//public class ProductService {
//	  @Inject
//	  ProductRepository ProductRepository;
//
//	  public Multi<Product> findAll() {
//	    return ProductRepository.streamAll()..onItem().transform(ProductService::mapToDomain);
//	  }
//
//	  public Uni<Product> findById(Long id) {
//	    return ProductRepository.findById(id)
//	        .onItem().ifNotNull().transform(ProductService::mapToDomain)
//	        .onItem().ifNull().failWith(() -> new WebApplicationException("Product not found", 404));
//	  }
//
//
//	  public Uni<Boolean> delete(Long id) {
//	    return Panache.withTransaction(() -> ProductRepository.deleteById(id));
//	  }
//
//	  public static Product mapToEntity(Product Product) {
//	    return new ObjectMapper().convertValue(Product, Product.class);
//	  }
//
//	  public static Product mapToDomain(Product entity) {
//	    return new ObjectMapper().convertValue(entity, Product.class);
//	  }
//	}


