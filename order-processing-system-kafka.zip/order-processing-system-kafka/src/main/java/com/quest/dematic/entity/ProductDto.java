package com.quest.dematic.entity;

import lombok.Data;

@Data
public class ProductDto {
	private Long id;

	private String productCode;

	private Double quantity;

	private Unit quantityUnit;

	private ProductStatus status;

	public Long getid() {
		return id;
	}

	public void setid(final Long id) {
		this.id = id;

	}

	public ProductStatus getstatus() {
		return status;
	}

	public void setstatus(ProductStatus status) {
		this.status = status;

	}

	public String getproductCode() {
		return productCode;
	}

	public void setproductCode(String productCode) {
		this.productCode = productCode;

	}

	public Unit getquantityUnit() {
		return quantityUnit;
	}

	public void setquantityUnit(Unit quantityUnit) {
		this.quantityUnit = quantityUnit;

	}

	public Double getquantity() {
		return quantity;
	}

	public void setquantity(Double quantity) {
		this.quantity = quantity;

	}

}
