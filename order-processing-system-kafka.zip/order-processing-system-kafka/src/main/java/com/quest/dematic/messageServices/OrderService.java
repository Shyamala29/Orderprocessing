package com.quest.dematic.messageServices;

import javax.enterprise.context.ApplicationScoped;
import com.quest.dematic.entity.Orders;

import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

@ApplicationScoped
	public interface OrderService {
	
	    Uni<Orders> getById(Long id);
	    Multi<Orders> getAll(Orders order);
	   
	    Uni<Orders> create(Orders order);
	    Uni<Orders> update(Long id, Orders order);
	    Uni<Void> deleteById(Long id);
	}
