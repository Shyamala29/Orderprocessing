package com.quest.dematic.repository;
import javax.enterprise.context.ApplicationScoped;

import com.quest.dematic.entity.Orders;

import io.quarkus.hibernate.reactive.panache.PanacheRepository;

@ApplicationScoped
public interface OrderRepository extends PanacheRepository<Orders>{
	

	}



