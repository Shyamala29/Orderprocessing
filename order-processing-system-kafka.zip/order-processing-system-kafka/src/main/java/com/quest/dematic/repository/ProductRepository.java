package com.quest.dematic.repository;

import javax.enterprise.context.ApplicationScoped;

import com.quest.dematic.entity.Product;

import io.quarkus.hibernate.reactive.panache.PanacheRepository;

@ApplicationScoped
public class ProductRepository implements PanacheRepository<Product>{

}
