package com.quest.dematic.messageServices;

import java.net.URI;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.quest.dematic.entity.Orders;
import com.quest.dematic.repository.OrderRepository;

import io.order.process.system.Common.BaseHttpException;
import io.quarkus.hibernate.reactive.panache.common.runtime.ReactiveTransactional;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

@ApplicationScoped
public class DefaultOrderService implements OrderService {
    private final OrderRepository orderRespository;

    public DefaultOrderService(OrderRepository orderRepository) {
        this.orderRespository = orderRepository;
    }

        @Override
        public Uni<Orders> getById(Long id) {
            return orderRespository.findById(id).replaceIfNullWith(() -> {
                throw new BaseHttpException(Response.Status.NOT_FOUND, "Orders not found with ID=" + id);
            });
        }

        @Override
        public Multi<Orders> getAll(Orders order) {
            return orderRespository.streamAll();
        }

   
        @ReactiveTransactional
        @Override
        public Uni<Orders> create(Orders order) {
            Orders newOrders = new Orders();
        
            newOrders.setstatus(order.getstatus());
            newOrders.setcreatedDate(order.getcreatedDate());
            return orderRespository.persistAndFlush(newOrders);
        }
       

        @ReactiveTransactional
        @Override
        public Uni<Orders> update(Long id, Orders order) {
            return orderRespository.findById(id)
                    .replaceIfNullWith(() -> {
                        throw new BaseHttpException(Response.Status.NOT_FOUND, "Order not found with ID=" + id);
                    })
                    .call(orderToUpdate -> {
                        orderToUpdate.setstatus(order.getstatus());
                        orderToUpdate.setcreatedDate(order.getcreatedDate());
                       
                        return orderRespository.persistAndFlush(orderToUpdate);
                    });
        }

        @ReactiveTransactional
        @Override
        public Uni<Void> deleteById(Long id) {
            return orderRespository.deleteById(id).replaceWithVoid();
        }
    }



