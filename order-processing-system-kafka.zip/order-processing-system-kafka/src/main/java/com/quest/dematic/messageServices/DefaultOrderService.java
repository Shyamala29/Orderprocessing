package com.quest.dematic.messageServices;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.core.Response;

import com.quest.dematic.entity.OrderStatus;
import com.quest.dematic.entity.Orders;
import com.quest.dematic.repository.OrderRepository;

import io.order.process.system.Common.BaseHttpException;
import io.quarkus.hibernate.reactive.panache.common.runtime.ReactiveTransactional;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;

@ApplicationScoped
public class DefaultOrderService implements OrderService {
    private final OrderRepository orderRespository;

    public DefaultOrderService(OrderRepository orderRepository) {
        this.orderRespository = orderRepository;
    }

        @Override
        public Uni<Orders> getById(Long id) {
            return orderRespository.findById(id).replaceIfNullWith(() -> {
                throw new BaseHttpException(Response.Status.NOT_FOUND, "Orders not found with ID=" + id);
            });
        }

        @Override
        public Multi<Orders> getAll() {
            return orderRespository.streamAll();
        }

   
        @ReactiveTransactional
        @Override
        public Uni<Orders> create(Orders order) {
            Orders newOrders = new Orders();

            newOrders.setstatus(order.getstatus());
            newOrders.setcreatedDate(order.getcreatedDate());
            newOrders.setorderLines(order.getorderLines()); 
            
            return orderRespository.persistAndFlush(newOrders);
        }
       

        @ReactiveTransactional
        @Override
        public Uni<Orders> update(Long id, OrderStatus status) {
            return orderRespository.findById(id)
                    .replaceIfNullWith(() -> {
                        throw new BaseHttpException(Response.Status.NOT_FOUND, "Order not found with ID=" + id);
                    })
                    .call(ord -> { ord.setstatus(status);
                         return orderRespository.persistAndFlush(ord);
                    });
        }

        @ReactiveTransactional
        @Override
        public Uni<Void> deleteById(Long id) {
            return orderRespository.deleteById(id).replaceWithVoid();
        }
    }



