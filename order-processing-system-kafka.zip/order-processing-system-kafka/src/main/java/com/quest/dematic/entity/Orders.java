package com.quest.dematic.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import io.quarkus.hibernate.reactive.panache.PanacheEntity;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Orders extends PanacheEntity {


	    @Column(unique = true, nullable = false)
	    private OrderStatus status;

	    @Column(nullable = false)
	    private LocalDate createdDate;

	
@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.EAGER)
@JoinColumn(name= "orderLines")
private List<Product> orderLines;
	
public OrderStatus getstatus() {
    return status;
}
public void setstatus(OrderStatus status) {
    this.status= status;
    
}
public LocalDate getcreatedDate() {
    return createdDate;
}
public void setcreatedDate(LocalDate createdDate) {
    this.createdDate= createdDate;
    
}

}
