package com.quest.dematic.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import io.smallrye.mutiny.Uni;
import lombok.Data;

@Data
public class OrderDtos {
	private Long id;
	private OrderStatus status;
	private LocalDate createdDate;
	public Long getid() {
        return id;
    }
    public void setid(final Long id) {
        this.id = id;
        
    }	
    public OrderStatus getstatus() {
        return status;
    }
    public void setstatus(OrderStatus status) {
        this.status= status;
        
    }
    public LocalDate getcreatedDate() {
        return createdDate;
    }
    public void setcreatedDate(LocalDate createdDate) {
        this.createdDate= createdDate;
        
    }
} 
	