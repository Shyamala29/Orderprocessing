package com.quest.dematic.entity;

import java.time.LocalDate;
import java.util.List;

import io.quarkus.hibernate.reactive.panache.PanacheEntity;
import lombok.Data;

@Data
public class OrderDtos {
	private Long id;
	private OrderStatus status;
	private LocalDate createdDate;
	private List<ProductDto> orderLines;

	public List<ProductDto> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(List<ProductDto> orderLines) {
		this.orderLines = orderLines;
	}

	public Long getid() {
		return id;
	}

	public void setid(final Long id) {
		this.id = id;

	}

	public OrderStatus getstatus() {
		return status;
	}

	public void setstatus(OrderStatus status) {
		this.status = status;

	}

	public LocalDate getcreatedDate() {
		return createdDate;
	}

	public void setcreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;

	}
}
