package com.quest.dematic.Responder;

import com.quest.dematic.entity.OrderDtos;
import com.quest.dematic.entity.Orders;
import com.quest.dematic.mapping.OrderDtosMapper;

import io.order.process.system.Common.Responder;
import io.smallrye.mutiny.Uni;
public class OrderUniResponder implements Responder<Uni<Orders>, Uni<OrderDtos>> {

	
	    private final OrderDtosMapper orderDtosMapper;

	    public OrderUniResponder(OrderDtosMapper orderDtosMapper) {
	        this.orderDtosMapper = orderDtosMapper;
	    }

	    @Override
	    public Uni<OrderDtos> respond(Uni<Orders> order) {
	        return order.onItem().transform(orderDtosMapper::map);
	    }
	}



