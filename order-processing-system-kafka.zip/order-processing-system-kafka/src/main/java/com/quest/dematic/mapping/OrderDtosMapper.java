package com.quest.dematic.mapping;



import java.util.List;
import java.util.stream.Collectors;

import com.quest.dematic.entity.OrderDtos;
import com.quest.dematic.entity.Orders;
import com.quest.dematic.entity.Product;
import com.quest.dematic.entity.ProductDto;

import io.order.process.system.Common.DataMapper;

public class OrderDtosMapper implements DataMapper<Orders, OrderDtos>{

	    @Override
	    public OrderDtos map(Orders order) {
	    	
	    	List<ProductDto> orderLines= null;
		      
	        if (order.getorderLines() != null) {
	            orderLines = order.getorderLines().stream().map(mapping -> {
	            	  ProductDto product = new ProductDto();
	                product.setid(mapping.getid());
	                product.setproductCode(mapping.getproductCode());
	                product.setquantityUnit(mapping.getquantityUnit());
	                product.setquantity(mapping.getquantity());
	                product.setstatus(mapping.getstatus());
	                return product;
	            }).collect(Collectors.toList());
	        }
	        OrderDtos dto = new OrderDtos();
	        dto.setid(order.id);
	        dto.setcreatedDate(order.getcreatedDate());
	        dto.setstatus(order.getstatus());
	        dto.setOrderLines(orderLines);
	
	        return dto;
	   
	        
	        
	    }
    }


