package com.quest.dematic.mapping;

import javax.xml.crypto.Data;

import com.quest.dematic.entity.OrderDtos;
import com.quest.dematic.entity.Orders;

import io.order.process.system.Common.DataMapper;

public class OrderDtosMapper implements DataMapper<Orders, OrderDtos>{

	    @Override
	    public OrderDtos map(Orders order) {
	        OrderDtos dto = new OrderDtos();
	      
	        dto.setcreatedDate(order.getcreatedDate());
	        dto.setstatus(order.getstatus());
	
	        return dto;
	    }
    }


