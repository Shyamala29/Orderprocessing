package com.quest.dematic.entity;

public enum OrderStatus {

	PENDING,
	COMPLETED
}
