package com.quest.dematic.resourses;


import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.transaction.Transactional;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.jboss.resteasy.reactive.RestPath;
import org.jboss.resteasy.reactive.RestQuery;

import com.quest.dematic.Responder.OrderMultiResponder;
import com.quest.dematic.Responder.OrderUniResponder;
import com.quest.dematic.entity.OrderDtos;
import com.quest.dematic.entity.Orders;
import com.quest.dematic.mapping.OrderDtosMapper;
import com.quest.dematic.messageServices.OrderService;

import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;



@Path("/orders")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@ApplicationScoped
public class OrderResource {
	
	    private final OrderService orderService;
	    private final OrderDtosMapper orderDtosMapper = new OrderDtosMapper();
	    private final OrderUniResponder orderUniResponder = new OrderUniResponder(orderDtosMapper);
	    private final OrderMultiResponder orderMultiResponder = new OrderMultiResponder(orderDtosMapper);

	    public OrderResource(OrderService orderService) {
	      this.orderService=orderService;
	    }
	    @GET
	    public Multi<OrderDtos> getAll(Orders order ) {
	        Multi<Orders> all = orderService.getAll(order);
	        return orderMultiResponder.respond(all);
	    }

	    @GET
	    @Path("/{id}")
	    public Uni<OrderDtos> getSingle(@RestPath Long id) {
	        Uni<Orders> order = orderService.getById(id);
	        return orderUniResponder.respond(order);
	    }

	    @POST
	    @Consumes(MediaType.APPLICATION_JSON)
	    public Uni<OrderDtos> create(Orders order) {
	        Uni<Orders> created = orderService.create(order);
	        return orderUniResponder.respond(created);
	    }

	    @PUT
	    @Path("/{id}")
	    @Consumes(MediaType.APPLICATION_JSON)
	    public Uni<OrderDtos> update(@RestPath Long id, Orders order) {
	        Uni<Orders> updated = orderService.update(id, order);
	        return orderUniResponder.respond(updated);
	    }

	    @DELETE
	    @Path("/{id}")
	    public Uni<Void> delete(@RestPath Long id) {
	        return orderService.deleteById(id);
	    }

	}

	
	