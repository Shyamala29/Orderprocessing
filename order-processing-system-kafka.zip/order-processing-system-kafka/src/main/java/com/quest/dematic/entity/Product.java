package com.quest.dematic.entity;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class Product {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
	private String productCode;
	
	private Double quantity;
	
	@Enumerated(EnumType.STRING)
	private Unit quantityUnit;
	
	@Enumerated(EnumType.STRING)
	private ProductStatus status;

	@ManyToOne
	private Orders orderLines;
	public Long getid() {
	    return id;
	}
	public void setid(Long id) {
	    this.id= id;
	    
	}
	public String getproductCode() {
	    return productCode;
	}
	public void setproductCode(String productCode) {
	    this.productCode= productCode;
	    
	}public Double getquantity() {
	    return quantity;
	}
	public void setquantity(Double quantity) {
	    this.quantity= quantity;
	    
	}public Unit getquantityUnit() {
	    return quantityUnit;
	}
	public void setquantityUnit(Unit quantityUnit) {
	    this.quantityUnit= quantityUnit;
	    
	}
	public ProductStatus getstatus() {
	    return status;
	}
	public void setstatus(ProductStatus status) {
	    this.status= status;
	    
	}
}
