package io.order.process.system.Common;
@FunctionalInterface

	public interface DataMapper<S, D> {
	    D map(final S source);
	}



