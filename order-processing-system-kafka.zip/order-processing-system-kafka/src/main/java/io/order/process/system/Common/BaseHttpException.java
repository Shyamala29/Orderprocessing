package io.order.process.system.Common;

import java.time.LocalDateTime;

import javax.ws.rs.core.Response;

public class BaseHttpException extends RuntimeException {

    private final Integer status;
    private final String message;
    private final LocalDateTime timestamp;

    public BaseHttpException(Response.Status status, String message) {
        this.status = status.getStatusCode();
        this.message = message;
        this.timestamp = LocalDateTime.now();
    }

    public Integer getStatus() {
        return status;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
 

}
