package io.order.process.system.Common;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class RuntimeExceptionHandler implements ExceptionMapper<RuntimeException> {
	private final Logger log = LoggerFactory.getLogger(RuntimeExceptionHandler.class);
    @Override
    public Response toResponse(RuntimeException e) {
    	
        log.error(e.getMessage(), e);
         

        ErrorData errorData = new ErrorData();
        errorData.setmessage(e.getMessage());
        errorData.setstatus(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
        errorData.settimestamp(LocalDateTime.now());

        return Response.status(errorData.getstatus()).entity(errorData).build();
    }
}