package io.order.process.system.Common;

@FunctionalInterface
public interface Responder<S, D> {
	    D respond(final S source);
	}


