package io.order.process.system.Common;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Provider
public class BaseHttpExceptionHandler implements ExceptionMapper<BaseHttpException> {
	
	    @Override
	    public Response toResponse(BaseHttpException e) {
	        ErrorData errorData = new ErrorData();
	        errorData.setmessage(e.getMessage());
	        errorData.setstatus(e.getStatus());
	        errorData.settimestamp(e.getTimestamp());
	        return Response.status(errorData.getstatus()).entity(errorData).build();
	    }
	}

