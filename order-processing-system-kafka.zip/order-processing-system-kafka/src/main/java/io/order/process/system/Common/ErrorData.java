package io.order.process.system.Common;

import java.time.LocalDateTime;

import lombok.Data;
@Data
public class ErrorData {

	    private String message;
	    private Integer status;
	    private LocalDateTime timestamp;
	    
	    public String getmessage() {
	        return message;
	    }
	    public void setmessage(final String message) {
	        this.message = message;
	}
	    public int getstatus() {
	        return status;
	    }
	    public void setstatus(final int status) {
	        this.status = status;
}
	    public LocalDateTime gettimestamp() {
	        return timestamp;
	    }
	    public void settimestamp(final LocalDateTime timestamp) {
	        this.timestamp = timestamp;
	    }
}

